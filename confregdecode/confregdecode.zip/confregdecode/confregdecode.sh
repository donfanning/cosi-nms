#!/bin/sh

#
# Copyright (c)2000 by cisco Systems, Inc.  All rights reserved.
# $Id: confregdecode.sh,v 1.1 2000/12/12 20:05:09 marcus Exp $
#

# Change this to your path to jre
JRE=/usr/local/jdk1.1.8/bin/jre
# End changeable things

CLASSPATH=cd.jar:${CLASSPATH}

exec ${JRE} -cp ${CLASSPATH} com.cisco.confregdecode.ConfregDecode
